package com.aeternalistech.tiles;

import com.aeternalistech.misc.ScrabbleException;

/**
 * The scores and distribution of English Scrabble.
 *
 * @author George Miller
 * @version 1.1
 * @since 1.1
 */
public class English extends Tiles {

    @Override
    public int getScore(char tile) throws ScrabbleException {
        tile = Character.toUpperCase(tile);

        switch (tile) {
            case '?':
                return 0;
            case 'E':
            case 'A':
            case 'I':
            case 'O':
            case 'N':
            case 'R':
            case 'T':
            case 'L':
            case 'S':
            case 'U':
                return 1;
            case 'D':
            case 'G':
                return 2;
            case 'B':
            case 'C':
            case 'M':
            case 'P':
                return 3;
            case 'F':
            case 'H':
            case 'V':
            case 'W':
            case 'Y':
                return 4;
            case 'K':
                return 5;
            case 'J':
            case 'X':
                return 8;
            case 'Q':
            case 'Z':
                return 10;
            default:
                throw new ScrabbleException("Illegal character for tile!");
        } //s
    }

    @Override
    public int getAmount(char tile) throws ScrabbleException {
        tile = Character.toUpperCase(tile);

        switch (tile) {
            case 'A':
                return 9;
            case 'B':
                return 2;
            case 'C':
                return 2;
            case 'D':
                return 4;
            case 'E':
                return 12;
            case 'F':
                return 2;
            case 'G':
                return 3;
            case 'H':
                return 2;
            case 'I':
                return 9;
            case 'J':
                return 1;
            case 'K':
                return 1;
            case 'L':
                return 4;
            case 'M':
                return 2;
            case 'N':
                return 6;
            case 'O':
                return 8;
            case 'P':
                return 2;
            case 'Q':
                return 1;
            case 'R':
                return 6;
            case 'S':
                return 4;
            case 'T':
                return 6;
            case 'U':
                return 4;
            case 'V':
                return 2;
            case 'W':
                return 2;
            case 'X':
                return 1;
            case 'Y':
                return 2;
            case 'Z':
                return 1;
            case '?':
                return 2;
            default:
                throw new ScrabbleException("Illegal character for tile!");
        } //s
    }

    @Override
    public char[] getTiles() {
        return new char[]{
            'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O',
            'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '?'
        };
    }

    @Override
    public String getName() {
        return "English";
    }

}
