package com.aeternalistech.tiles;

import com.aeternalistech.misc.ScrabbleException;

/**
 * The data about a tiles for each language.
 *
 * @author George Miller
 * @version 1.1
 * @since 1.1
 */
public abstract class Tiles {

    /**
     * Get the score of a tile.
     *
     * @param tile The letter on the tile. Use a question mark for a blank tile.
     * @return The score of the tile.
     * @throws ScrabbleException The char isn't a valid tile.
     */
    public abstract int getScore(char tile) throws ScrabbleException;

    /**
     * Get the number of times the character is used.
     *
     * @param tile The letter on the tile. Use a question mark for a blank tile.
     * The score of the tile.
     * @return The number of times the tile is used.
     * @throws ScrabbleException The char isn't a valid tile.
     */
    public abstract int getAmount(char tile) throws ScrabbleException;

    /**
     * Get the tiles that are present in this language.
     *
     * @return The tiles that are present in this language.
     */
    public abstract char[] getTiles();

    /**
     * Get the name of the language.
     *
     * @return The name of the language.
     */
    public abstract String getName();

    /**
     * Check that a character is a legal tile.
     *
     * @param check Character to check.
     * @return True if the tile is legal, false if not.
     */
    public boolean legalTile(char check) {
        char[] tiles = getTiles();

        //Is this one of the tiles in the getTiles method?
        for (char tile : tiles) {
            if (check == tile) {
                return true;
            } //i
        } //fe

        //This char is not legal.
        return false;
    }
}
