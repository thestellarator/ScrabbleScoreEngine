package com.aeternalistech.debug;

import com.aeternalistech.board.ScrabbleBoard;
import com.aeternalistech.events.WordEvent;
import com.aeternalistech.io.TextFileIO;
import com.aeternalistech.misc.ScrabbleException;
import com.aeternalistech.scoring.TwoPlayerScoringEngine;
import com.aeternalistech.scoring.MultiPlayer;
import com.aeternalistech.scoring.ScoreData;
import com.aeternalistech.scoring.TwoPlayerStorage;
import com.aeternalistech.tiles.English;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Test and debug scoring engine.
 *
 * @author George Miller
 * @version 1.1
 * @since 1.1
 */
public class Debug {

    /**
     * The scores of a Scrabble game. Alternates between player 1 and 2.
     */
    private static final String[] SCORES = {
        "OILED, F8, H", "WILLER, G7, V",
        "MOO, I9, H", "-, -, -",
        "-, -, -", "TREADING, F12, H",
        "HIT, K11, V", "RACES, E4, V",
        "LOG, M10, V", "ARGUING, C3, H",
        "TOASTI??, C1, V", "-, -, -",
        "LIE, M10, H", "FRENZIED, O8, V",
        "JAG, A8, H", "-, -, -",
        "VANE, H1, V", "WE, G7, H",
        "TAX, I11, V", "PARTIED, L3, V",
        "BI, M2, V", "PICK, L3, H",
        "YE, N14, H", "AN, M14, V",
        "TRY, F12, V", "ASK, O1, V",
        "FAB, K4, H", "HATE, A1, H",
        "HU, A1, V", "POOR, C13, H",
        "QUEEN, I15, H", "TUM, L6, H",
        "POW, C13, V", "NON, D12, V"
    };

    /**
     * The data of player 1.
     */
    private final static List<ScoreData> PLAYER1 = new ArrayList<>();

    /**
     * The data of player 2.
     */
    private final static List<ScoreData> PLAYER2 = new ArrayList<>();

    /**
     * Static constructor.
     */
    static {
        for (int i = 0; i < SCORES.length; i++) {
            if ((i % 2) == 0) {
                PLAYER1.add(ScoreData.fromSingleString(SCORES[i]));
            } else {
                PLAYER2.add(ScoreData.fromSingleString(SCORES[i]));
            } //ie
        } //f
    }

    /**
     * Debug the score storage class.
     *
     * @param saveLocation File to store the scores in.
     * @throws ScrabbleException Scrabble error.
     * @throws IOException IO error.
     */
    public void debugStorage(String saveLocation) throws ScrabbleException, IOException {
        MultiPlayer mp = new MultiPlayer(new English(), "Player1", "Player2");
        TwoPlayerStorage storage = new TwoPlayerStorage(mp);
        ScrabbleBoard board = ScrabbleBoard.getInstance();
        board.addChangeListener((WordEvent e) -> {
            //System.out.println(e.getWord());
        });

        for (int i = 0; i < PLAYER1.size(); i++) {
            //Player 1.
            ScoreData player1 = PLAYER1.get(i);
            mp.setScore(player1);
            storage.addScore(player1);
            if (!player1.isSkip()) {
                board.addWord(player1);
            } //i
            mp.nextTurn();

            //Player 2.
            ScoreData player2 = PLAYER2.get(i);
            mp.setScore(player2);
            storage.addScore(player2);
            if (!player2.isSkip()) {
                board.addWord(player2);
            } //i
            mp.nextTurn();
        } //f

        TextFileIO.writeTextFile(saveLocation, storage.toString());
    }

    /**
     * Debug the game class.
     *
     * @param saveLocation File to store the scores in.
     * @throws com.aeternalistech.misc.ScrabbleException Scrabble error.
     * @throws java.io.IOException IO error.
     */
    public void debugGame(String saveLocation) throws ScrabbleException, IOException {
        TwoPlayerScoringEngine game = new TwoPlayerScoringEngine(new English(), "Player1", "Player2");

        for (int i = 0; i < PLAYER1.size(); i++) {
            ScoreData player1 = PLAYER1.get(i);
            game.addWord(player1);

            ScoreData player2 = PLAYER2.get(i);
            game.addWord(player2);
        } //f
        
        game.calculateEndScore();

        TextFileIO.writeTextFile(saveLocation, game.getScore());
    }
}
