package com.aeternalistech.tokenizer;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * A tokenizer in which the tokens can be connected by any character, not just a
 * space.
 *
 * @author George Miller
 * @version 1.1
 * @since 1.1
 */
public class GeneralTokenizer implements Tokenizer {

    /**
     * The tokens extracted from the String.
     */
    private final List<String> tokens = new ArrayList<>();

    /**
     * The current index;
     */
    private int index = 0;

    /**
     * Create new instance of GeneralTokenizer.
     *
     * @param string The string to parse.
     * @param connector The character that is used to separate tokens inside the
     * string. Any amount of space goes unrecognised too.
     */
    public GeneralTokenizer(String string, char connector) {
        //Replace all instances of connector with a space.
        char[] chars = string.toCharArray();
        StringBuilder build = new StringBuilder();
        for (int i = 0; i < chars.length; i++) {
            if (chars[i] == connector) {
                build.append(" ");
            } else {
                build.append(chars[i]);
            } //ie
        } //f

        try {
            //Tokenize using the SpaceTokenizer.
            Tokenizer tokenizer = new SpaceTokenizer(build.toString());
            while (tokenizer.hasMoreTokens()) {
                tokens.add(tokenizer.getNextToken());
            } //w
        } catch (TokenizerException ex) {
        } //tc
    }

    @Override
    public boolean hasMoreTokens() {
        return index < tokens.size();
    }

    @Override
    public String getNextToken() throws TokenizerException {
        if (!hasMoreTokens()) {
            throw new TokenizerException("No more tokens to extract!");
        } //i

        return tokens.get(index++);
    }

    @Override
    public String[] getTokens() {
        String[] tokenCopy = new String[tokens.size()];

        for (int i = 0; i < tokenCopy.length; i++) {
            tokenCopy[i] = tokens.get(index);
        } //f

        return tokenCopy;
    }

    @Override
    public Iterator<String> iterator() {
        return new Iterator<String>() {

            /**
             * Index of iterator array currently pointed to.
             */
            private int iteratorIndex = 0;

            @Override
            public boolean hasNext() {
                return (iteratorIndex != tokens.size());
            }

            @Override
            public String next() {
                return tokens.get(iteratorIndex++);
            }

            @Override
            public void remove() {
            }
        };
    }
}
