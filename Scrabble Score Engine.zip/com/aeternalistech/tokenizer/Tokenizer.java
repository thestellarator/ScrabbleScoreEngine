package com.aeternalistech.tokenizer;

/**
 * An interface to be implemented by classes that split strings into tokens.
 * Tokens are keywords and symbols that have meaning during compilation. The
 * tokens may be separated by spaces, or it may be legal for some tokens to be
 * next to each other without a space or other character or string of characters
 * between them. It is the job of the Tokenizer to detect the presence of the
 * tokens and extract all of them.
 *
 * @author George Miller
 * @version 1.1
 * @since 1.1
 */
public interface Tokenizer extends Iterable<String> {

    /**
     * Has the tokenizer any more tokens to return?
     *
     * @return True if there are more tokens to return, false if there are not.
     */
    public boolean hasMoreTokens();

    /**
     * Get the next token.
     *
     * @return The next token.
     * @throws TokenizerException There are no more tokens.
     */
    public String getNextToken() throws TokenizerException;

    /**
     * Get all tokens as an array.
     *
     * @return All tokens as an array.
     */
    public String[] getTokens();
}
