package com.aeternalistech.tokenizer;

/**
 * Exception has occurred during splitting the program into tokens.
 *
 * @author George Miller
 * @version 1.1
 * @since 1.1
 */
public class TokenizerException extends Exception {

    /**
     * Creates a new instance of <code>TokenizerException</code> without detail
     * message.
     */
    public TokenizerException() {
    }

    /**
     * Constructs an instance of <code>TokenizerException</code> with the
     * specified detail message.
     *
     * @param msg the detail message.
     */
    public TokenizerException(String msg) {
        super(msg);
    }
}
