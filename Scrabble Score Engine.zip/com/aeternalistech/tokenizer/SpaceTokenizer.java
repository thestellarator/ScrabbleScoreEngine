package com.aeternalistech.tokenizer;

import com.aeternalistech.tokenizer.TokenizerException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

/**
 * Splits a String into tokens, in which each collection of characters separated
 * by a space is considered a space. So the String "this is a string" would be
 * split into the tokens [this, is, a, string].
 *
 * @author George Miller
 * @version 1.1
 * @since 1.1
 */
public class SpaceTokenizer implements Tokenizer {

    /**
     * Tokens extracted from string.
     */
    private final String[] tokens;
    /**
     * Index of the array currently pointed to.
     */
    private int index = 0;

    /**
     * Create new instance of SpaceTokenizer and split the String passed into
     * the method into tokens based upon the location of spaces.
     *
     * @param text Text to be split into tokens.
     * @throws TokenizerException Exception occurred splitting text into tokens.
     */
    public SpaceTokenizer(String text) throws TokenizerException {
        //Add spaces at start and end
        text = " " + text + " ";

        int length = text.length();
        char[] characters = text.toCharArray();

        //Check for starts of words
        List<Integer> starts = new ArrayList();
        for (int i = 1; i < length; i++) {
            char a = characters[i - 1];
            char b = characters[i];

            if (a == ' ' && b != ' ') {
                starts.add(i);
            } //i
        } //i

        //Check for ends of words
        List<Integer> ends = new ArrayList();
        for (int i = 0; i < length - 1; i++) {
            char a = characters[i];
            char b = characters[i + 1];

            if (a != ' ' && b == ' ') {
                ends.add(i);
            } //i
        } //i

        if (starts.size() != ends.size()) {
            throw new TokenizerException("Different number of token starts and ends!");
        } //i

        int numberOfTokens = starts.size();
        tokens = new String[numberOfTokens];

        for (int i = 0; i < numberOfTokens; i++) {
            int start = starts.get(i);
            int end = ends.get(i);

            StringBuilder build = new StringBuilder();
            for (int j = start; j <= end; j++) {
                build.append(characters[j]);
            } //f

            tokens[i] = build.toString();
        } //f
    }

    @Override
    public boolean hasMoreTokens() {
        return index != tokens.length;
    }

    @Override
    public String getNextToken() throws TokenizerException {
        boolean hasMoreTokens = hasMoreTokens();
        if (!hasMoreTokens) {
            throw new TokenizerException("There are no more tokens!");
        } //i

        return tokens[index++];
    }

    @Override
    public String[] getTokens() {
        return tokens;
    }

    @Override
    public Iterator<String> iterator() {
        return new Iterator<String>() {

            /**
             * Index of iterator array currently pointed to.
             */
            private int iteratorIndex = 0;

            @Override
            public boolean hasNext() {
                return (iteratorIndex != tokens.length);
            }

            @Override
            public String next() {
                return tokens[iteratorIndex++];
            }

            @Override
            public void remove() {
            }
        };
    }

}
