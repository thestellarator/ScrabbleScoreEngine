package com.aeternalistech.coordinate;

import com.aeternalistech.enums.ScanDirection;
import com.aeternalistech.misc.ScrabbleException;
import com.aeternalistech.misc.ScrabbleUtils;
import java.util.List;
import java.util.Objects;

/**
 * A 2D coordinate on the Scrabble board.
 *
 * @author George Miller
 * @version 1.1
 * @since 1.1
 */
public class Coordinate {

    /**
     * The x-coordinate of the Scrabble board.
     */
    private final String x;

    /**
     * The y-coordinate of the Scrabble board.
     */
    private final String y;

    /**
     * Create new instance of Coordinate.
     *
     * @param x The x-coordinate of the Scrabble board.
     * @param y The y-coordinate of the Scrabble board.
     */
    public Coordinate(String x, String y) {
        this.x = x;
        this.y = y;
    }

    /**
     * Create new instance of Coordinate.
     *
     * @param coordinate The Coordinate in a single String.
     * @throws ScrabbleException The String doesn't represent a valid
     * Coordinate.
     */
    public Coordinate(String coordinate) throws ScrabbleException {
        List<Coordinate> board = ScrabbleUtils.scanBoard(ScanDirection.X_FIRST);

        boolean found = false;

        String xStore = null;
        String yStore = null;

        for (Coordinate scan : board) {
            String scanString = scan.getX() + scan.getY();

            if (scanString.equals(coordinate)) {
                xStore = scan.getX();
                yStore = scan.getY();
                found = true;
                break;
            } //i
        } //f

        this.x = xStore;
        this.y = yStore;

        if (found == false) {
            throw new ScrabbleException("Invalid coordinate String!");
        } //i
    }

    /**
     * Get the x-coordinate of the Scrabble board.
     *
     * @return The x-coordinate of the Scrabble board.
     */
    public String getX() {
        return x;
    }

    /**
     * Get the y-coordinate of the Scrabble board.
     *
     * @return The y-coordinate of the Scrabble board.
     */
    public String getY() {
        return y;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 53 * hash + Objects.hashCode(this.x);
        hash = 53 * hash + Objects.hashCode(this.y);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        } //i
        if (obj == null) {
            return false;
        } //i
        if (getClass() != obj.getClass()) {
            return false;
        } //i
        final Coordinate other = (Coordinate) obj;
        if (!Objects.equals(this.x, other.x)) {
            return false;
        } //i
        return Objects.equals(this.y, other.y);
    }

    @Override
    public String toString() {
        return "Coordinate{" + "x=" + x + ", y=" + y + '}';
    }

    /**
     * Create a copy of this Coordinate Object.
     *
     * @return A copy of this Coordinate Object.
     */
    public Coordinate copy() {
        Coordinate coordinate = new Coordinate(this.x, this.y);
        return coordinate;
    }
}
