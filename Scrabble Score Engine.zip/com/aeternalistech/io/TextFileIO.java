package com.aeternalistech.io;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Read text file.
 *
 * @author George Miller
 * @version 1.1
 * @since 1.1
 */
public class TextFileIO {

    /**
     * Private constructor - util.
     */
    private TextFileIO() {
    }

    /**
     * Fully read the contents of a text file and convert it to a string.
     *
     * @param path Path to the text file on the local file system.
     * @return The contents of the text file as a String.
     * @throws IOException Error reading file.
     */
    public static String readTextFile(String path) throws IOException {
        FileInputStream fis = null;
        BufferedInputStream bis = null;

        String textFile = null;

        try {
            fis = new FileInputStream(path);
            bis = new BufferedInputStream(fis);

            StringBuilder sb = new StringBuilder();

            File file = new File(path);
            int size = (int) file.length();
            byte data[] = new byte[size];
            bis.read(data);

            for (int i = 0; i < size; i++) {
                sb.append((char) data[i]);
            } //f

            textFile = sb.toString();
        } finally {
            if (bis != null) {
                bis.close();
            } //i
            if (fis != null) {
                fis.close();
            } //i
        } //tf

        return textFile;
    }

    /**
     * Fully read the contents of a text file and convert it into a List of
     * Characters.
     *
     * @param path Path to the text file on the local file system.
     * @return The contents of the text file as a List of Characters.
     * @throws IOException Error reading file.
     */
    public static List<Character> getCharacters(String path) throws IOException {
        FileInputStream fis = null;
        BufferedInputStream bis = null;

        List<Character> list = new ArrayList<>();

        try {
            fis = new FileInputStream(path);
            bis = new BufferedInputStream(fis);

            File file = new File(path);
            int size = (int) file.length();
            byte data[] = new byte[size];
            bis.read(data);

            for (int i = 0; i < size; i++) {
                list.add((char) data[i]);
            } //f
        } finally {
            if (bis != null) {
                bis.close();
            } //i
            if (fis != null) {
                fis.close();
            } //i
        } //tf

        return list;
    }

    /**
     * Write a String to a text file.
     *
     * @param path Path to the text file.
     * @param text String to write to the text file.
     * @throws IOException Error writing file.
     */
    public static void writeTextFile(String path, String text) throws IOException {
        FileOutputStream fos = null;
        BufferedOutputStream bos = null;

        try {
            fos = new FileOutputStream(path);
            bos = new BufferedOutputStream(fos);

            char[] characters = text.toCharArray();
            for (char character : characters) {
                bos.write(character);
            } //f
        } finally {
            if (bos != null) {
                bos.close();
            } //i
            if (fos != null) {
                fos.close();
            } //i
        } //tf
    }

    /**
     * Write a List of Characters to a text file.
     *
     * @param path Path to the text file.
     * @param text A List of Characters to write to the text file.
     * @throws IOException Error writing file.
     */
    public static void writeTextFile(String path, List<Character> text)
            throws IOException {
        FileOutputStream fos = null;
        BufferedOutputStream bos = null;

        try {
            fos = new FileOutputStream(path);
            bos = new BufferedOutputStream(fos);

            for (char character : text) {
                bos.write(character);
            } //f
        } finally {
            if (bos != null) {
                bos.close();
            } //i
            if (fos != null) {
                fos.close();
            } //i
        } //tf
    }
}
