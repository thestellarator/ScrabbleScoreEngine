package com.aeternalistech.bonus;

/**
 * The value of a bonus on the Scrabble board.
 *
 * @author George Miller
 * @version 1.1
 * @since 1.1
 */
public enum Bonus {

    /**
     * There is no bonus at this coordinate.
     */
    NO_BONUS,
    /**
     * There is a double letter bonus at this coordinate.
     */
    DOUBLE_LETTER,
    /**
     * There is a triple letter bonus at this coordinate.
     */
    TRIPLE_LETTER,
    /**
     * There is a double word bonus at this coordinate.
     */
    DOUBLE_WORD,
    /**
     * There is a triple word bonus at this coordinate.
     */
    TRIPLE_WORD,
    /**
     * There is a start bonus at this coordinate.
     */
    STAR

}
