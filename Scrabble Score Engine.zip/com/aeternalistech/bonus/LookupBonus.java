package com.aeternalistech.bonus;

import com.aeternalistech.coordinate.Coordinate;
import com.aeternalistech.enums.ScanDirection;
import com.aeternalistech.misc.ScrabbleException;
import com.aeternalistech.misc.ScrabbleUtils;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Look up the value of the bonus at any coordinate on the board.
 *
 * @author George Miller
 * @version 1.1
 * @since 1.1
 */
public class LookupBonus {

    /**
     * There is no bonus at this coordinate.
     */
    private static final int NO_BONUS = 0;

    /**
     * There is a double letter bonus at this coordinate.
     */
    private static final int DOUBLE_LETTER = 1;

    /**
     * There is a triple letter bonus at this coordinate.
     */
    private static final int TRIPLE_LETTER = 2;

    /**
     * There is a double word bonus at this coordinate.
     */
    private static final int DOUBLE_WORD = 3;

    /**
     * There is a triple word bonus at this coordinate.
     */
    private static final int TRIPLE_WORD = 4;

    /**
     * There is a start bonus at this coordinate.
     */
    private static final int STAR = 5;

    /**
     * The layout of the Scrabble board.
     */
    private static final int[][] BOARD_LAYOUT = {
        {4, 0, 0, 1, 0, 0, 0, 4, 0, 0, 0, 1, 0, 0, 4},
        {0, 3, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 3, 0},
        {0, 0, 3, 0, 0, 0, 1, 0, 1, 0, 0, 0, 3, 0, 0},
        {1, 0, 0, 3, 0, 0, 0, 1, 0, 0, 0, 3, 0, 0, 1},
        {0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0},
        {0, 2, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 2, 0},
        {0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0},
        {4, 0, 0, 1, 0, 0, 0, 5, 0, 0, 0, 1, 0, 0, 4},
        {0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0},
        {0, 2, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 2, 0},
        {0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0},
        {1, 0, 0, 3, 0, 0, 0, 1, 0, 0, 0, 3, 0, 0, 1},
        {0, 0, 3, 0, 0, 0, 1, 0, 1, 0, 0, 0, 3, 0, 0},
        {0, 3, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 3, 0},
        {4, 0, 0, 1, 0, 0, 0, 4, 0, 0, 0, 1, 0, 0, 4},};

    /**
     * Mapping of coordinates to bonuses. This may change as tiles are added
     * (bonuses are no longer accessible once a tile has been placed over them.)
     * The instance is static as there's only one board.
     */
    private static final Map<Coordinate, Bonus> BOARD = new HashMap<>();

    /**
     * Static constructor.
     */
    static {
        reset();
    }
    
    /**
     * Private constructor - util class.
     */
    private LookupBonus() {
        throw new AssertionError("Cannot create LookupBonus!");
    }

    /**
     * Reset the bonus values on the board after the tiles have been removed
     * after a game.
     */
    public static void reset() {
        List<Coordinate> scan = ScrabbleUtils.scanBoard(ScanDirection.X_FIRST);

        int i = 0;
        for (int y = 0; y < 15; y++) {
            for (int x = 0; x < 15; x++) {
                //Map coordinate to bonus.
                Coordinate coord = scan.get(i++);
                int bonus = BOARD_LAYOUT[x][y];
                
                //Check if anything is in board map. Remove if it is.
                Bonus old = BOARD.get(coord);
                if(old != null) {
                    BOARD.remove(coord);
                } //i

                //Add new version.
                switch (bonus) {
                    case NO_BONUS:
                        BOARD.put(coord, Bonus.NO_BONUS);
                        break;
                    case DOUBLE_LETTER:
                        BOARD.put(coord, Bonus.DOUBLE_LETTER);
                        break;
                    case TRIPLE_LETTER:
                        BOARD.put(coord, Bonus.TRIPLE_LETTER);
                        break;
                    case DOUBLE_WORD:
                        BOARD.put(coord, Bonus.DOUBLE_WORD);
                        break;
                    case TRIPLE_WORD:
                        BOARD.put(coord, Bonus.TRIPLE_WORD);
                        break;
                    case STAR:
                        BOARD.put(coord, Bonus.STAR);
                        break;
                } //s
            } //f
        } //f
    }

    /**
     * Get the bonus of one of the Scrabble board's squares.
     *
     * @param coordinate The coordinate of the Scrabble board's squares.
     * @return The bonus value of Scrabble board's squares.
     * @throws ScrabbleException The coordinate is invalid.
     */
    public static Bonus getBonus(Coordinate coordinate) throws ScrabbleException {
        Bonus bonus = BOARD.get(coordinate);

        if (bonus == null) {
            throw new ScrabbleException("Invalid coordinate!");
        } //i

        return bonus;
    }

    /**
     * Remove the bonus of one of the Scrabble board's squares. Used when a tile
     * is placed over a square.
     *
     * @param coordinate The coordinate of the Scrabble board's squares.
     * @throws ScrabbleException The coordinate is invalid.
     */
    public static void removeBonus(Coordinate coordinate) throws ScrabbleException {
        Bonus bonus = BOARD.get(coordinate);

        if (bonus == null) {
            throw new ScrabbleException("Invalid coordinate!");
        } //i

        //If there's no bonus here already there's no need to remove it.
        if (bonus == Bonus.NO_BONUS) {
            return;
        }

        BOARD.remove(coordinate);
        BOARD.put(coordinate, Bonus.NO_BONUS);
    }
}
