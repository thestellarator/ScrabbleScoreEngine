package com.aeternalistech.board;

import com.aeternalistech.scoring.ScoreData;
import com.aeternalistech.bonus.Bonus;
import com.aeternalistech.bonus.LookupBonus;
import com.aeternalistech.coordinate.Coordinate;
import com.aeternalistech.enums.Compass;
import com.aeternalistech.enums.LegalPosition;
import com.aeternalistech.enums.WordDirection;
import com.aeternalistech.misc.ScrabbleException;
import com.aeternalistech.misc.ScrabbleUtils;
import com.aeternalistech.tiles.Tiles;
import java.util.ArrayList;
import java.util.List;

/**
 * Checks whether or not a word is legal in its current position. Also checks
 * whether blank tiles should replace other letters.
 *
 * @author George Miller
 * @version 1.1
 * @since 1.1
 */
public class LegalCheck {

    /**
     * The language that is being used.
     */
    private final Tiles tiles;

    /**
     * Create new instance of LegalPosition.
     *
     * @param tiles The language currently being used.
     */
    public LegalCheck(Tiles tiles) {
        this.tiles = tiles;
    }

    /**
     * Checks if the move entered overlaps tiles on the board in an illegal
     * fashion. This means that the word put down has a tile overlap a different
     * tile that is non blank. The word is not necessarily fully legal (it might
     * not connect to another word) so this can be used to check words that are
     * being built.
     *
     * @param data The word to check.
     * @return The word that is being checked. Some tiles may be replaced with
     * question marks if blank overlapping occurs.
     * @throws ScrabbleException This means that illegal placement has occurred.
     */
    public String checkIllegalOverlap(ScoreData data) throws ScrabbleException {
        //Check that the word contains only legal tiles.
        String word = data.getWord();
        char[] tileChars = word.toCharArray();

        for (char tile : tileChars) {
            if (!tiles.legalTile(tile)) {
                throw new ScrabbleException(tile + " is not a legal tile for " + tiles.getName() + "!");
            }
        } //fe

        //Check that there is no illegal overlaps.
        ScrabbleBoard board = ScrabbleBoard.getInstance();
        Coordinate coordinate = data.getCoordinate();
        int length = word.length();
        WordDirection direction = data.getDirection();

        //Create new word, checking for blank tiles.
        StringBuilder build = new StringBuilder();

        Coordinate move = coordinate.copy();
        for (int i = 0; i < length; i++) {
            //Check tile on word and on board.
            if (!ScrabbleUtils.isLegalCoordinate(move)) {
                throw new ScrabbleException("Coordinate is not on board!");
            } //i
            char wordChar = tileChars[i];
            char boardChar = board.getLetter(move);

            if (boardChar == ' ') {
                //No tile is here, nothing to check.
                build.append(wordChar);
            } else if (boardChar == '?') {
                //Any letter is legal, return blank.
                build.append('?');
            } else if (wordChar == boardChar) {
                //Legal overlap
                build.append(wordChar);
            } else {
                //Illegal overlap.
                throw new ScrabbleException("Illegal tile overlap at " + move.toString() + "!");
            } //ie 

            if (direction == WordDirection.HORIZONTAL) {
                move = ScrabbleUtils.move(move, Compass.EAST);
            } else {
                move = ScrabbleUtils.move(move, Compass.SOUTH);
            } //ie
        } //f

        return build.toString();
    }

    /**
     * Check that the word is legally placed on the board. This means that it
     * overlaps another word on the board or is perpendicular to a word on the
     * board. If overlap occurs then the tiles on the word must always be the
     * same as on the board, unless the board is a blank tile (the blank tile is
     * assumed to be anything.) Assuming that the word hasn't been placed on the
     * board.
     *
     * @param data The data of the word.
     * @param isFirstTurn Whether or not it is the first turn. There are no
     * other words to check on the first turn.
     * @return True if the word is fully legal, false if not.
     * @throws com.aeternalistech.misc.ScrabbleException Error in word.
     */
    public LegalPosition checkFullyLegal(ScoreData data, boolean isFirstTurn) throws ScrabbleException {
        try {
            //Check that there's no illegal overlap.
            checkIllegalOverlap(data);
        } catch (ScrabbleException ex) {
            return LegalPosition.NOT_LEGAL;
        } //tc //tc //tc //tc

        if (!isFirstTurn) {
            //OVERLAP CHECK
            /**
             * Check that the word overlaps a word currently placed on the
             * board. It must be legal by default so there's no need to check
             * the tiles, only that overlap occurs.
             */
            ScrabbleBoard board = ScrabbleBoard.getInstance();
            List<Coordinate> position = data.getPosition();

            //Check that there's an overlap.
            for (int i = 0; i < position.size(); i++) {
                //Check if this overlaps with a board tile.
                char tile = board.getLetter(position.get(i));
                if (tile != ' ') {
                    return LegalPosition.OVERLAP;
                } //i
            } //f

            //PERPENDICULAR CHECK
            /**
             * If overlap didn't occur then check that the word is perpendicular
             * to another.
             */
            WordDirection direction = data.getDirection();
            List<Coordinate> parallel;
            if (direction == WordDirection.HORIZONTAL) {
                //Horizontal facing word.
                parallel = parallelHorizontal(data);
            } else {
                //Vertical facing word.
                parallel = parallelVertical(data);
            } //ie

            for (Coordinate square : parallel) {
                char tile = board.getLetter(square);
                if (tile != ' ') {
                    return LegalPosition.PARALLEL;
                } //i
            } //fe
        } else {
            //Check the word goes through the star.
            List<Coordinate> position = data.getPosition();

            //Check that there's an overlap.
            for (int i = 0; i < position.size(); i++) {
                //Check if this overlaps with a board tile.
                if (LookupBonus.getBonus(position.get(i)).equals(Bonus.STAR)) {
                    return LegalPosition.FIRST;
                } //i
            } //f

            //Word never passed star
            return LegalPosition.NOT_LEGAL;
        } //ie

        //The word is not legally placed.
        return LegalPosition.NOT_LEGAL;
    }

    /**
     * Get the coordinates of all tiles parallel to the word if it's facing
     * horizontal.
     *
     * @param data The data of the word.
     * @return The Coordinates of all parallel tiles.
     */
    private List<Coordinate> parallelHorizontal(ScoreData data) {
        List<Coordinate> coordinates = new ArrayList<>();

        String word = data.getWord();
        Coordinate move = data.getCoordinate();
        for (int i = 0; i < word.length(); i++) {
            //Get the tile above, if it's accessible.
            try {
                Coordinate copy = move.copy();
                Coordinate above = ScrabbleUtils.move(copy, Compass.NORTH);
                coordinates.add(above);
            } catch (ScrabbleException ex) {
            } //tc

            //Get the tile below, if it's accessible.
            try {
                Coordinate copy = move.copy();
                Coordinate below = ScrabbleUtils.move(copy, Compass.SOUTH);
                coordinates.add(below);
            } catch (ScrabbleException ex) {
            } //tc

            //Move right.
            try {
                move = ScrabbleUtils.move(move, Compass.EAST);
            } catch (ScrabbleException ex) {
            } //tc
        } //f

        return coordinates;
    }

    /**
     * Get the coordinates of all tiles parallel to the word if it's facing
     * vertical.
     *
     * @param data The data of the word.
     * @return The Coordinates of all parallel tiles.
     */
    private List<Coordinate> parallelVertical(ScoreData data) {
        List<Coordinate> coordinates = new ArrayList<>();

        String word = data.getWord();
        Coordinate move = data.getCoordinate();
        for (int i = 0; i < word.length(); i++) {
            //Get the tile right, if it's accessible.
            try {
                Coordinate copy = move.copy();
                Coordinate above = ScrabbleUtils.move(copy, Compass.EAST);
                coordinates.add(above);
            } catch (ScrabbleException ex) {
            } //tc

            //Get the tile left, if it's accessible.
            try {
                Coordinate copy = move.copy();
                Coordinate below = ScrabbleUtils.move(copy, Compass.WEST);
                coordinates.add(below);
            } catch (ScrabbleException ex) {
            } //tc

            //Move down.
            try {
                move = ScrabbleUtils.move(move, Compass.SOUTH);
            } catch (ScrabbleException ex) {
            } //tc
        } //f

        return coordinates;
    }
}
