package com.aeternalistech.board;

import com.aeternalistech.scoring.ScoreData;
import com.aeternalistech.coordinate.Coordinate;
import com.aeternalistech.misc.ScrabbleException;
import com.aeternalistech.tiles.Tiles;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * The tiles left to use.
 *
 * @author George Miller
 * @version 1.1
 * @since 1.1
 */
public class TilesLeft {

    /**
     * The tiles left.
     */
    private char[] tilesLeft;

    /**
     * Private constructor - singleton class.
     */
    private TilesLeft() {
    }

    /**
     * Reset the tiles.
     *
     * @param language The language of the game.
     */
    public void reset(Tiles language) {
        char[] tiles = language.getTiles();

        StringBuilder build = new StringBuilder();

        for (char tile : tiles) {
            try {
                int tileAmount = language.getAmount(tile);

                for (int i = 0; i < tileAmount; i++) {
                    build.append(tile);
                } //f
            } catch (ScrabbleException ex) {
            } //tc
        } //fe

        tilesLeft = build.toString().toCharArray();
    }

    /**
     * Remove a word from the tile set.
     *
     * @param data Data of the word to remove. This must be be added to the
     * board at some point.
     * @throws com.aeternalistech.misc.ScrabbleException The word isn't placed
     * on the board.
     */
    public void removeWord(ScoreData data) throws ScrabbleException {
        Set<Integer> indices = new HashSet<>();

        //Split the word into lettters by reading board.
        List<Coordinate> coordinates = data.getAdded();
        ScrabbleBoard board = ScrabbleBoard.getInstance();

        char[] letters = new char[coordinates.size()];
        for (int i = 0; i < letters.length; i++) {
            letters[i] = board.getLetter(coordinates.get(i));
        } //f        

        int blanks = 0;
        for (int i = 0; i < letters.length; i++) {
            if (letters[i] == ' ') {
                blanks++;
            } //i
        } //f

        //Check if the word hasn't been added.
        if (blanks > 0) {
            throw new ScrabbleException("Word not placed!");
        } //i        

        //Search if this word can be built from these tiles.
        for (int i = 0; i < letters.length; i++) {
            for (int j = 0; j < tilesLeft.length; j++) {
                if (letters[i] == tilesLeft[j] && !indices.contains(j)) {
                    indices.add(j);
                    break;
                } //i
            } //f
        } //f

        //Copy these tiles over to a new array without these indices.
        List<Character> list = new ArrayList<>();
        for (int i = 0; i < tilesLeft.length; i++) {
            if (!indices.contains(i)) {
                list.add(tilesLeft[i]);
            } //i
        } //f

        char[] copy = new char[list.size()];
        for (int i = 0; i < list.size(); i++) {
            copy[i] = list.get(i);
        } //f
        this.tilesLeft = copy;
    }

    /**
     * Get the tiles left.
     *
     * @return The tiles left.
     */
    public String getTilesLeft() {
        return new String(tilesLeft);
    }

    /**
     * Get instance of singleton class.
     *
     * @return Instance of singleton class.
     */
    public static TilesLeft getInstance() {
        return TilesLeftHolder.INSTANCE;
    }

    /**
     * Singleton class holder.
     */
    private static class TilesLeftHolder {

        /**
         * Singleton class.
         */
        private static final TilesLeft INSTANCE = new TilesLeft();
    }
}
