package com.aeternalistech.board;

import com.aeternalistech.scoring.ScoreData;
import com.aeternalistech.coordinate.Coordinate;
import com.aeternalistech.enums.ScanDirection;
import com.aeternalistech.events.WordEvent;
import com.aeternalistech.events.WordListener;
import com.aeternalistech.misc.ScrabbleException;
import com.aeternalistech.misc.ScrabbleUtils;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Stores the current position of the letters on the Scrabble board. the class
 * is a singleton as there's only a single Scrabble board.
 *
 * @author George Miller.
 * @version 1.1
 * @since 1.1
 */
public class ScrabbleBoard {

    /**
     * The current position of tiles on the board.
     */
    private Map<Coordinate, Character> board = new HashMap<>();
    
    /**
     * Listeners for board changing.
     */
    private final List<WordListener> boardChangeListeners = new ArrayList<>();

    /**
     * Private class as it's a singleton class.
     */
    private ScrabbleBoard() {
    }

    /**
     * Reset the board after a game.
     */
    public void reset() {
        board = new HashMap();
    }

    /**
     * Add listener for board change.
     * @param listener Listener for board change to add.
     */
    public void addChangeListener(WordListener listener) {
        boardChangeListeners.add(listener);
    }
    
    /**
     * Remove listener for board change.
     * @param listener Listener for board change to remove.
     */
    public void removeChangeListener(WordListener listener) {
        boardChangeListeners.add(listener);
    }
    
    /**
     * Fire all attached board change listeners.
     */
    private void fireChangeListeners() {
        String boardLayout = debug();
        WordEvent e = new WordEvent(this, boardLayout);
        
        boardChangeListeners.stream().forEach((listener) -> {
            listener.wordEvent(e);
        });
    }
    
    /**
     * Add a word to the board.
     *
     * @param turnData The turn data representing the word.
     * @throws ScrabbleException An error occurred while adding the word.
     */
    public void addWord(ScoreData turnData) throws ScrabbleException {
        List<Coordinate> added = new ArrayList<>();

        String word = turnData.getWord();
        char[] tiles = word.toCharArray();
        List<Coordinate> squares = turnData.getPosition();

        for (int i = 0; i < tiles.length; i++) {
            //Test for legal overlap.
            Character currentSquare = board.get(squares.get(i));

            if (currentSquare == null) {
                //Square is currently empty, anything can be put here.
                board.put(squares.get(i), tiles[i]);
                added.add(squares.get(i));
            } else if (currentSquare == '?') {
                //Blank tile, assume legal overlap.
                //Don't change blank tile.
            } else if (currentSquare == tiles[i]) {
                //This tile is already on the board.
            } else {
                //Remove word before throwing exception.
                added.stream().forEach((square) -> {
                    board.remove(square);
                });

                throw new ScrabbleException("Illegal overlap at " + squares.get(i).toString() + "!");
            } //ie 
        } //f

        turnData.setAdded(added);
        fireChangeListeners();
    }

    /**
     * Add the squares that the tiles are added to.
     *
     * @param turnData The TurnData to have the squares added to.
     * @throws ScrabbleException The word cannot be added here.
     */
    public void addSquares(ScoreData turnData) throws ScrabbleException {
        List<Coordinate> added = new ArrayList<>();

        String word = turnData.getWord();
        char[] tiles = word.toCharArray();
        List<Coordinate> squares = turnData.getPosition();

        for (int i = 0; i < tiles.length; i++) {
            //Test for legal overlap.
            Character currentSquare = board.get(squares.get(i));

            if (currentSquare == null) {
                //Square is currently empty, anything can be put here.
                added.add(squares.get(i));
            } else if (currentSquare == '?' || currentSquare == tiles[i]) {
            } else {
                throw new ScrabbleException("Illegal overlap at " + squares.get(i).toString() + "!");
            } //ie 
        } //f

        turnData.setAdded(added);
    }

    /**
     * Remove word from board. This function can only be used if the TurnData
     * has been passed to the addWord or addSquares method at least once.
     *
     * @param turnData The word to remove from the board.
     */
    public void removeWord(ScoreData turnData) {
        List<Coordinate> added = turnData.getAdded();

        //If the empty List is empty the remove function can't be used.
        if (added.isEmpty()) {
            return;
        } //i

        added.stream().forEach((square) -> {
            board.remove(square);
        });
        
        fireChangeListeners();
    }

    /**
     * Get a letter at a square on the Scrabble board. If the letter is empty
     * the method returns a space (the character ' ').
     *
     * @param coordinate The coordinate of the square.
     * @return The letter at this square.
     */
    public char getLetter(Coordinate coordinate) {
        Character letter = board.get(coordinate);

        if (letter == null) {
            return ' ';
        } else {
            return letter;
        } //ie
    }

    /**
     * Show the current layout of the Scabble board.
     *
     * @return The current layout of the Scabble board.
     */
    public String debug() {
        StringBuilder build = new StringBuilder();

        List<Coordinate> scan = ScrabbleUtils.scanBoard(ScanDirection.X_FIRST);

        int i = 0;
        for (int y = 0; y < 15; y++) {
            for (int x = 0; x < 15; x++) {
                Character tile = board.get(scan.get(i++));

                if (tile == null) {
                    build.append("-");
                } else {
                    build.append(tile);
                } //ie
            } //f
            build.append("\n");
        } //f

        return build.toString();
    }

    /**
     * Get the instance of the ScrabbleBoard.
     *
     * @return The instance of the ScrabbleBoard.
     */
    public static ScrabbleBoard getInstance() {
        return ScrabbleBoardHolder.INSTANCE;
    }

    /**
     * Singleton holder.
     */
    private static class ScrabbleBoardHolder {

        /**
         * Singleton class.
         */
        private static final ScrabbleBoard INSTANCE = new ScrabbleBoard();
    }
}
