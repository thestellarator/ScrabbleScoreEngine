
package com.aeternalistech.misc;

/**
 * An error has occurred at some point during data input.
 *
 * @author George Miller
 * @version 1.1
 * @since 1.1
 */
public class ScrabbleException extends Exception {

    /**
     * Creates a new instance of <code>ScrabbleException</code> without detail
     * message.
     */
    public ScrabbleException() {
    }

    /**
     * Constructs an instance of <code>ScrabbleException</code> with the
     * specified detail message.
     *
     * @param msg the detail message.
     */
    public ScrabbleException(String msg) {
        super(msg);
    }
}
