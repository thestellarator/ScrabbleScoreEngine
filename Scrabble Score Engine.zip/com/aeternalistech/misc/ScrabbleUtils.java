package com.aeternalistech.misc;

import com.aeternalistech.enums.ScanDirection;
import com.aeternalistech.enums.WordDirection;
import com.aeternalistech.coordinate.Coordinate;
import com.aeternalistech.enums.Compass;
import com.aeternalistech.tokenizer.GeneralTokenizer;
import com.aeternalistech.tokenizer.Tokenizer;
import com.aeternalistech.tokenizer.TokenizerException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Utility functions.
 *
 * @author George Miller
 * @version 1.1
 * @since 1.1
 */
public class ScrabbleUtils {

    /**
     * The markers used to denote the x-axes of the Scrabble board.
     */
    private static final String[] X_MARKERS = new String[]{
        "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O"
    };

    /**
     * The markers used to denote the y-axes of the Scrabble board.
     */
    private static final String[] Y_MARKERS = new String[]{
        "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15"
    };

    /**
     * Coordinates that are legal for the board.
     */
    private static Set<Coordinate> legalBoardCoordinates = new HashSet<>();

    /**
     * Static constructor.
     */
    static {
        List<Coordinate> scan = scanBoard(ScanDirection.X_FIRST);
        scan.stream().forEach((square) -> {
            legalBoardCoordinates.add(square);
        });
    }

    /**
     * Private constructor - utility class.
     */
    private ScrabbleUtils() {
        throw new AssertionError("Cannor create ScrabbleUtil!");
    }

    /**
     * Change the values used to mark the x-axes of the Scrabble board.
     *
     * @param newMarkers The values used to mark the x-axes of the Scrabble
     * board.
     * @throws ScrabbleException The array has an invalid length.
     */
    public static void setXMarkers(String[] newMarkers) throws ScrabbleException {
        if (newMarkers.length != 15) {
            throw new ScrabbleException("Marker array has invalid length!");
        } //i

        System.arraycopy(newMarkers, 0, X_MARKERS, 0, 15);

        //Reset legal coordinates.
        legalBoardCoordinates = new HashSet<>();
        List<Coordinate> scan = scanBoard(ScanDirection.X_FIRST);
        scan.stream().forEach((square) -> {
            legalBoardCoordinates.add(square);
        });
    }

    /**
     * Change the values used to mark the x-axes of the Scrabble board.
     *
     * @param newMarkers The values used to mark the x-axes of the Scrabble
     * board. This is in the form of a comma separated string such as "A, B, C,
     * D" if [A, B, C, D] will be the array to be entered.
     * @throws ScrabbleException There are too few tokens in the string.
     */
    public static void setXMarkers(String newMarkers) throws ScrabbleException {
        try {
            Tokenizer tokenizer = new GeneralTokenizer(newMarkers, ',');

            String[] markerArray = new String[15];
            for (int i = 0; i < 15; i++) {
                markerArray[i] = tokenizer.getNextToken();
            } //f

            System.arraycopy(markerArray, 0, X_MARKERS, 0, 15);

            //Reset legal coordinates.
            legalBoardCoordinates = new HashSet<>();
            List<Coordinate> scan = scanBoard(ScanDirection.X_FIRST);
            scan.stream().forEach((square) -> {
                legalBoardCoordinates.add(square);
            });
        } catch (TokenizerException ex) {
            throw new ScrabbleException("Marker string has too few tokens!");
        } //tc
    }

    /**
     * Get the values used to mark the x-axes of the Scrabble board.
     *
     * @return The values used to mark the x-axes of the Scrabble board.
     */
    public static String[] getXMarkers() {
        String[] markers = new String[15];
        System.arraycopy(X_MARKERS, 0, markers, 0, 15);
        return markers;
    }

    /**
     * Change the values used to mark the y-axes of the Scrabble board.
     *
     * @param newMarkers The values used to mark the y-axes of the Scrabble
     * board.
     * @throws ScrabbleException The array has an invalid length.
     */
    public static void setYMarkers(String[] newMarkers) throws ScrabbleException {
        if (newMarkers.length != 15) {
            throw new ScrabbleException("Marker array has invalid length!");
        } //i

        System.arraycopy(newMarkers, 0, Y_MARKERS, 0, 15);

        //Reset legal coordinates.
        legalBoardCoordinates = new HashSet<>();
        List<Coordinate> scan = scanBoard(ScanDirection.X_FIRST);
        scan.stream().forEach((square) -> {
            legalBoardCoordinates.add(square);
        });
    }

    /**
     * Change the values used to mark the y-axes of the Scrabble board.
     *
     * @param newMarkers The values used to mark the y-axes of the Scrabble
     * board. This is in the form of a comma separated string such as "A, B, C,
     * D" if [A, B, C, D] will be the array to be entered.
     * @throws ScrabbleException There are too few tokens in the string.
     */
    public static void setYMarkers(String newMarkers) throws ScrabbleException {
        try {
            Tokenizer tokenizer = new GeneralTokenizer(newMarkers, ',');

            String[] markerArray = new String[15];
            for (int i = 0; i < 15; i++) {
                markerArray[i] = tokenizer.getNextToken();
            } //f

            System.arraycopy(markerArray, 0, Y_MARKERS, 0, 15);

            //Reset legal coordinates.
            legalBoardCoordinates = new HashSet<>();
            List<Coordinate> scan = scanBoard(ScanDirection.X_FIRST);
            scan.stream().forEach((square) -> {
                legalBoardCoordinates.add(square);
            });
        } catch (TokenizerException ex) {
            throw new ScrabbleException("Marker string has too few tokens!");
        } //tc
    }

    /**
     * Get the values used to mark the y-axes of the Scrabble board.
     *
     * @return The values used to mark the y-axes of the Scrabble board.
     */
    public static String[] getYMarkers() {
        String[] markers = new String[15];
        System.arraycopy(Y_MARKERS, 0, markers, 0, 15);
        return markers;
    }

    /**
     * Check if a coordinate is on the Scrabble board.
     *
     * @param coordinate Coordinate to check.
     * @return true if the coordinate is legal, false if it is not.
     */
    public static boolean isLegalCoordinate(Coordinate coordinate) {
        return legalBoardCoordinates.contains(coordinate);
    }

    /**
     * Scan all coordinates on the board.
     *
     * @param direction Which direction the scan should proceed.
     * @return The coordinates of the Scrabble board.
     */
    public static List<Coordinate> scanBoard(ScanDirection direction) {
        List<Coordinate> scan = new ArrayList<>();

        if (direction == ScanDirection.X_FIRST) {
            //X-first (row scan).
            for (int y = 0; y < 15; y++) {
                for (int x = 0; x < 15; x++) {
                    Coordinate coord = new Coordinate(X_MARKERS[x], Y_MARKERS[y]);
                    scan.add(coord);
                } //f
            } //f
        } else {
            //Y-first (column scan).
            for (int x = 0; x < 15; x++) {
                for (int y = 0; y < 15; y++) {
                    Coordinate coord = new Coordinate(X_MARKERS[x], Y_MARKERS[y]);
                    scan.add(coord);
                } //f
            } //f
        } //ie

        return scan;
    }

    /**
     * Get the coordinates of the squares of a Scrabble word.
     *
     * @param coord The coordinate of the first square of the word.
     * @param direction The direction of the word is pointing.
     * @param length The length of the word.
     * @return The coordinates of the squares of the word.
     * @throws ScrabbleException An error occurred while scanning.
     */
    public static List<Coordinate> scanWord(Coordinate coord, WordDirection direction, int length) throws ScrabbleException {
        List<Coordinate> scan = new ArrayList<>();

        //Find the start coordinate.
        String xStart = coord.getX();
        int xIndex = -1;
        for (int i = 0; i < 15; i++) {
            if (X_MARKERS[i].equals(xStart)) {
                xIndex = i;
                break;
            } //i
        } //f

        if (xIndex == -1) {
            throw new ScrabbleException("Unrecognised x-marker!");
        } //i

        String yStart = coord.getY();
        int yIndex = -1;
        for (int i = 0; i < 15; i++) {
            if (Y_MARKERS[i].equals(yStart)) {
                yIndex = i;
                break;
            } //i
        } //f

        if (yIndex == -1) {
            throw new ScrabbleException("Unrecognised y-marker!");
        } //i

        if (direction == WordDirection.HORIZONTAL) {
            //Horizontal. The y value is fixed, the x value moves up.
            for (int i = 0; i < length; i++) {
                try {
                    String coordString = X_MARKERS[xIndex] + Y_MARKERS[yIndex];
                    Coordinate coordinate = new Coordinate(coordString);
                    scan.add(coordinate);

                    xIndex++;
                } catch (ArrayIndexOutOfBoundsException e) {
                    throw new ScrabbleException("Word of the board!");
                } //tc
            } //f
        } else {
            //Vertical. The x value is fixed the y value moves up.
            for (int i = 0; i < length; i++) {
                try {
                    String coordString = X_MARKERS[xIndex] + Y_MARKERS[yIndex];
                    Coordinate coordinate = new Coordinate(coordString);
                    scan.add(coordinate);

                    yIndex++;
                } catch (ArrayIndexOutOfBoundsException e) {
                    throw new ScrabbleException("Word of the board!");
                } //tc
            } //f

        } //ie

        return scan;
    }

    /**
     * Move the Coordinate one square north, east, south or west.
     *
     * @param current The current coordinate.
     * @param direction The direction to move the coordinate.
     * @return The coordinate after moving.
     * @throws com.aeternalistech.misc.ScrabbleException The current coordinate
     * is invalid or it is invalid after moving.
     */
    public static Coordinate move(Coordinate current, Compass direction) throws ScrabbleException {
        String currentX = current.getX();
        String currentY = current.getY();

        //Lookup x and y index.
        int xIndex = -1;
        int yIndex = -1;

        for (int i = 0; i < 15; i++) {
            if (currentX.equals(X_MARKERS[i])) {
                xIndex = i;
                break;
            } //i
        } //f
        if (xIndex == -1) {
            throw new ScrabbleException("Unrecognized x marker!");
        } //i

        for (int i = 0; i < 15; i++) {
            if (currentY.equals(Y_MARKERS[i])) {
                yIndex = i;
                break;
            } //i
        } //f
        if (yIndex == -1) {
            throw new ScrabbleException("Unrecognized y marker!");
        } //i

        switch (direction) {
            case NORTH:
                yIndex--;
                break;
            case EAST:
                xIndex++;
                break;
            case SOUTH:
                yIndex++;
                break;
            case WEST:
                xIndex--;
                break;
        } //s

        if (xIndex < 0 || xIndex >= 15) {
            throw new ScrabbleException("Of the Scrabble board on x-axis!");
        } //i        
        if (yIndex < 0 || yIndex >= 15) {
            throw new ScrabbleException("Of the Scrabble board on y-axis!");
        } //i

        return new Coordinate(X_MARKERS[xIndex], Y_MARKERS[yIndex]);
    }
}
