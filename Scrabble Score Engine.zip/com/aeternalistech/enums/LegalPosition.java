
package com.aeternalistech.enums;

/**
 * The result of a test for if the word is fully legal.
 * 
 * @author George Miller
 * @version 1.1
 * @since 1.1
 */
public enum LegalPosition {
    
    /**
     * This is the first move. (This is the 1st test carried out)
     */
    FIRST,
    
    /**
     * The word overlaps another word. (This is the 2nd test carried out)
     */
    OVERLAP,
    
    /**
     * The word is parallel to another word. (This is the 3rd test carried out)
     */
    PARALLEL,
    
    /**
     * The word is not legal.
     */
    NOT_LEGAL
}
