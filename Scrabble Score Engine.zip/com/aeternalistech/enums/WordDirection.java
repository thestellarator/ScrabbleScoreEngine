
package com.aeternalistech.enums;

/**
 * The direction of a word on the Scrabble board.
 *
 * @author George Miller
 * @version 1.1
 * @since 1.1
 */
public enum WordDirection {
    
    /**
     * The word is pointing horizontally.
     */
    HORIZONTAL,
    /**
     * The word is pointing vertically.
     */
    VERTICAL
}
