package com.aeternalistech.enums;

/**
 * The direction of a board scan. (Due to the symmetry of the board this won't
 * actually make a difference).
 *
 * @author George Miller
 * @version 1.1
 * @since 1.1
 */
public enum ScanDirection {
    /**
     * Scan along the x-axis first (a row scan).
     */
    X_FIRST, /**
     * Scan along the y-axis first (a column scan).
     */
    Y_FIRST

}
