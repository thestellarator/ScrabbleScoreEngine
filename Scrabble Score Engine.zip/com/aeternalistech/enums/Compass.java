package com.aeternalistech.enums;

/**
 * The directions on the compass. Used for quick navigation about the Scrabble
 * board.
 *
 * @author George Miller
 * @version 1.1
 * @since 1.1
 */
public enum Compass {
    /**
     * Move one square north (up).
     */
    NORTH,
    /**
     * Move one square east (right).
     */
    EAST,
    /**
     * Move one square south (down).
     */
    SOUTH,
    /**
     * Move one square west (left).
     */
    WEST

}
