package com.aeternalistech.events;

import java.util.EventListener;

/**
 * Listener for WordEvent objects.
 *
 * @author George Miller
 * @version 1.1
 * @since 1.1
 */
public interface WordListener extends EventListener {

    /**
     * A word event has taken place.
     *
     * @param e WordEvent object to be passed to listeners.
     */
    public void wordEvent(WordEvent e);
}
