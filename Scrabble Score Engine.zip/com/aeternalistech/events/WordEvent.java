package com.aeternalistech.events;

import java.util.EventObject;

/**
 * Event data carrying data about word changes.
 *
 * @author George Miller
 * @version 1.1
 * @since 1.1
 */
public class WordEvent extends EventObject {

    /**
     * The word.
     */
    private final String word;

    /**
     * Create new instance of WordEvent.
     *
     * @param source The source of the event.
     * @param word The word to be passed to listeners.
     */
    public WordEvent(Object source, String word) {
        super(source);
        this.word = word;
    }

    /**
     * Get the word.
     *
     * @return The word.
     */
    public String getWord() {
        return word;
    }

}
