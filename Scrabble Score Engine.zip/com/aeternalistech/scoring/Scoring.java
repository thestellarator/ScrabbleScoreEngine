package com.aeternalistech.scoring;

import com.aeternalistech.board.ScrabbleBoard;
import com.aeternalistech.bonus.Bonus;
import com.aeternalistech.bonus.LookupBonus;
import com.aeternalistech.coordinate.Coordinate;
import com.aeternalistech.enums.Compass;
import com.aeternalistech.enums.WordDirection;
import com.aeternalistech.misc.ScrabbleException;
import com.aeternalistech.misc.ScrabbleUtils;
import com.aeternalistech.tiles.Tiles;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Determine the score of a single word and multiple words connected together.
 *
 * @author George Miller
 * @version 1.1
 * @since 1.1
 */
public class Scoring {

    /**
     * The language of the game.
     */
    private final Tiles tiles;

    /**
     * Create new instance of Scoring.
     *
     * @param tiles The language of the game.
     */
    public Scoring(Tiles tiles) {
        this.tiles = tiles;
    }

    /**
     * Get the score of a single word. Assumes that this word hasn't been placed
     * on the born yet, throws an exception if it has.
     *
     * @param turnData Turn data of a word.
     * @return The score of the word.
     * @throws ScrabbleException There is an error with the turn data.
     */
    public int getSingleScore(ScoreData turnData) throws ScrabbleException {
        //Return 0 if this is a skip turn.
        if (turnData.isSkip()) {
            return 0;
        } //i

        ScrabbleBoard board = ScrabbleBoard.getInstance();
        board.addWord(turnData);
        int score = 0;

        //Convert to HashSet for easy lookup.
        List<Coordinate> added = turnData.getAdded();
        Set<Coordinate> addedSet = new HashSet<>();
        added.stream().forEach((square) -> {
            addedSet.add(square);
        });

        //Times score should be multiplied by.
        int bonusMultiply = 1;

        List<Coordinate> squares = turnData.getPosition();
        for (Coordinate square : squares) {
            //Check if this is a blank tile
            //Get value of letter.
            char tile = board.getLetter(square);
            int tileValue;
            if (tile == '?') {
                tileValue = 0;
            } else {
                tileValue = tiles.getScore(tile);
            } //ie

            //Does this word contain this square? If so, lookup bonus.
            if (addedSet.contains(square)) {
                Bonus bonus = LookupBonus.getBonus(square);

                switch (bonus) {
                    case DOUBLE_LETTER:
                        tileValue *= 2;
                        break;
                    case TRIPLE_LETTER:
                        tileValue *= 3;
                        break;
                    case DOUBLE_WORD:
                    case STAR:
                        bonusMultiply *= 2;
                        break;
                    case TRIPLE_WORD:
                        bonusMultiply *= 3;
                        break;
                } //s
            } //i

            score += tileValue;
        } //fe

        score *= bonusMultiply;

        //Have all tiles been used?
        if (added.size() == 7) {
            score += 50;
        } //i

        board.removeWord(turnData);
        return score;
    }

    /**
     * Get the score of a word and all connected words.
     *
     * @param data Data of word.
     * @return Score of word and all connected words.
     * @throws ScrabbleException An error occurred when parsing the score.
     */
    public int getMultipleScores(ScoreData data) throws ScrabbleException {
        if (data.isSkip()) {
            return 0;
        } //i

        //Add word and connceted words together into one list.
        List<ScoreData> allData = new ArrayList<>();
        allData.add(data);

        List<ScoreData> connectedList = connectedScan(data);
        connectedList.stream().forEach((element) -> {
            allData.add(element);
        });

        //Find the score of all these 
        int score = 0;
        for (ScoreData sd : allData) {
            int sdScore = getSingleScore(sd);
            score += sdScore;
        } //fe

        return score;
    }

    /**
     * See the total score and the data of the sub-scores.
     *
     * @param data The data of the score.
     * @return The overall score.
     * @throws ScrabbleException An error occurred when parsing the score.
     */
    public String getScoreData(ScoreData data) throws ScrabbleException {
        //Add word and connceted words together into one list.
        List<ScoreData> allData = new ArrayList<>();
        allData.add(data);

        List<ScoreData> connectedList = connectedScan(data);
        connectedList.stream().forEach((element) -> {
            allData.add(element);
        });

        StringBuilder build = new StringBuilder();

        //Find the score of all these 
        int score = 0;
        for (ScoreData sd : allData) {
            int sdScore = getSingleScore(sd);
            score += sdScore;

            build.append(sd.toString());
            build.append(" ");
            build.append(sdScore);
            build.append("\n");
        } //fe

        build.append("Total score: ");
        build.append(score);
        build.append("\n");

        return build.toString();
    }

    /**
     * Scan the board for connected words.
     *
     * @param scoreData The score data of the word with connected words.
     * @return All words connected to it.
     */
    private List<ScoreData> connectedScan(ScoreData scoreData) {
        if (scoreData.getDirection() == WordDirection.HORIZONTAL) {
            return horizontalScan(scoreData);
        } else {
            return verticalScan(scoreData);
        } //ie
    }

    /**
     * Add the data for the connected words of a horizontal word.
     *
     * @param scoreData The score data of a horizontal word.
     * @return The score data of any words connected to this word.
     */
    private List<ScoreData> horizontalScan(ScoreData scoreData) {
        ScrabbleBoard board = ScrabbleBoard.getInstance();
        List<ScoreData> data = new ArrayList<>();

        boolean remove = true;
        try {
            board.addWord(scoreData);
        } catch (ScrabbleException ex) {
            remove = false;
        } //tc

        List<Coordinate> squares = scoreData.getAdded();

        squares.stream().forEach((square) -> {
            Coordinate[] upDown = scanUpDown(square);
            if (upDown.length != 1) {
                //Get word
                StringBuilder build = new StringBuilder();
                //Move down south
                Coordinate moveSouth = upDown[0].copy();

                boolean breakNext = false;

                while (true) {
                    char tile = board.getLetter(moveSouth);
                    build.append(tile);

                    try {
                        moveSouth = ScrabbleUtils.move(moveSouth, Compass.SOUTH);
                    } catch (ScrabbleException ex) {
                    } //tc

                    if (breakNext) {
                        break;
                    } //i

                    //Has the scan reached the bottom? Break on the next round.
                    if (moveSouth.equals(upDown[1])) {
                        breakNext = true;
                    } //i
                } //w
                String word = build.toString();
                String coord = upDown[0].getX() + upDown[0].getY();
                String direction = "V";

                ScoreData sd = ScoreData.fromSingleString(word + ", " + coord + ", " + direction);
                data.add(sd);
            } //i
        });

        if (remove) {
            board.removeWord(scoreData);
        } //i

        return data;
    }

    /**
     * Scan up and down from a certain point to find where a word begins and
     * ends.
     *
     * @param coordinate The coordinate of a tile.
     * @return The coordinates of the top and bottom of the word around this
     * tile, if it exists, otherwise just this tile.
     */
    private Coordinate[] scanUpDown(Coordinate coordinate) {
        ScrabbleBoard board = ScrabbleBoard.getInstance();

        Coordinate north = coordinate.copy();
        //Scan up north as far as possible.
        while (true) {
            //Check if moved off board.
            try {
                north = ScrabbleUtils.move(north, Compass.NORTH);
            } catch (ScrabbleException ex) {
                break;
            } //tc

            //Check if this is over a tile already.
            Character tile = board.getLetter(north);
            if (tile.equals(' ')) {
                try {
                    //Moved up one place too high.
                    north = ScrabbleUtils.move(north, Compass.SOUTH);
                } catch (ScrabbleException ex) {
                } //tc
                break;
            } //i
        } //w

        //Scan down south as far as possible.
        Coordinate south = coordinate.copy();
        //Scan up north as far as possible.
        while (true) {
            //Check if moved off board.
            try {
                south = ScrabbleUtils.move(south, Compass.SOUTH);
            } catch (ScrabbleException ex) {
                break;
            } //tc

            //Check if this is over a tile already.
            Character tile = board.getLetter(south);
            if (tile.equals(' ')) {
                try {
                    //Moved down one place too low.
                    south = ScrabbleUtils.move(south, Compass.NORTH);
                } catch (ScrabbleException ex) {
                } //tc
                break;
            } //i
        } //w

        //Check if the same position.
        if (north.equals(south)) {
            Coordinate[] coords = new Coordinate[1];
            coords[0] = north;
            return coords;
        } else {
            Coordinate[] coords = new Coordinate[2];
            coords[0] = north;
            coords[1] = south;
            return coords;
        } //ie
    }

    /**
     * Add the data for the connected words of a vertical word.
     *
     * @param scoreData The score data of a vertical word.
     * @return The score data of any words connected to this word.
     */
    private List<ScoreData> verticalScan(ScoreData scoreData) {
        ScrabbleBoard board = ScrabbleBoard.getInstance();
        List<ScoreData> data = new ArrayList<>();

        boolean remove = true;
        try {
            board.addWord(scoreData);
        } catch (ScrabbleException ex) {
            remove = false;
        } //tc

        List<Coordinate> squares = scoreData.getAdded();

        squares.stream().forEach((square) -> {
            Coordinate[] leftRight = scanLeftRight(square);
            if (leftRight.length != 1) {
                //Get word
                StringBuilder build = new StringBuilder();
                //Move down south
                Coordinate moveEast = leftRight[0].copy();

                boolean breakNext = false;

                while (true) {
                    char tile = board.getLetter(moveEast);
                    build.append(tile);

                    try {
                        moveEast = ScrabbleUtils.move(moveEast, Compass.EAST);
                    } catch (ScrabbleException ex) {
                    } //tc

                    if (breakNext) {
                        break;
                    } //i

                    //Has the scan reached the bottom? Break on the next round.
                    if (moveEast.equals(leftRight[1])) {
                        breakNext = true;
                    } //i
                } //w
                String word = build.toString();
                String coord = leftRight[0].getX() + leftRight[0].getY();
                String direction = "H";

                ScoreData sd = ScoreData.fromSingleString(word + ", " + coord + ", " + direction);
                data.add(sd);
            } //i
        });

        if (remove) {
            board.removeWord(scoreData);
        } //i

        return data;
    }

    /**
     * Scan left and right from a certain point to find where a word begins and
     * ends.
     *
     * @param coordinate The coordinate of a tile.
     * @return The coordinates of the top and bottom of the word around this
     * tile, if it exists, otherwise just this tile.
     */
    private Coordinate[] scanLeftRight(Coordinate coordinate) {
        ScrabbleBoard board = ScrabbleBoard.getInstance();

        Coordinate east = coordinate.copy();
        //Scan up east as far as possible.
        while (true) {
            //Check if moved off board.
            try {
                east = ScrabbleUtils.move(east, Compass.EAST);
            } catch (ScrabbleException ex) {
                break;
            } //tc

            //Check if this is over a tile already.
            Character tile = board.getLetter(east);
            if (tile.equals(' ')) {
                try {
                    //Moved up one place too far.
                    east = ScrabbleUtils.move(east, Compass.WEST);
                } catch (ScrabbleException ex) {
                } //tc
                break;
            } //i
        } //w

        //Scan west as far as possible.
        Coordinate west = coordinate.copy();
        //Scan up north as far as possible.
        while (true) {
            //Check if moved off board.
            try {
                west = ScrabbleUtils.move(west, Compass.WEST);
            } catch (ScrabbleException ex) {
                break;
            } //tc

            //Check if this is over a tile already.
            Character tile = board.getLetter(west);
            if (tile.equals(' ')) {
                try {
                    //Moved down one place too far.
                    west = ScrabbleUtils.move(west, Compass.EAST);
                } catch (ScrabbleException ex) {
                } //tc
                break;
            } //i
        } //w

        //Check if the same position.
        if (east.equals(west)) {
            Coordinate[] coords = new Coordinate[1];
            coords[0] = east;
            return coords;
        } else {
            Coordinate[] coords = new Coordinate[2];
            coords[0] = west;
            coords[1] = east;
            return coords;
        } //ie
    }

}
