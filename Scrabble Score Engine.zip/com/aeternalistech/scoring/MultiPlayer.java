
package com.aeternalistech.scoring;

import com.aeternalistech.misc.ScrabbleException;
import com.aeternalistech.tiles.Tiles;

/**
 * Multiplayer engine.
 * 
 * @author George Miller
 * 
 * @version 1.1
 * @since 1.1
 */
public class MultiPlayer {
    
    /**
     * The name of player 1.
     */
    private String player1;

    /**
     * The score of player 1.
     */
    private int score1 = 0;

    /**
     * The name of player 2.
     */
    private String player2;

    /**
     * The score of player 2.
     */
    private int score2 = 0;

    /**
     * The name of player 3, if player 3 exists, null if he/she does not.
     */
    private String player3;

    /**
     * The score of player 3.
     */
    private int score3 = 0;

    /**
     * The name of player 4, if player 4 exists, null if he/she does not.
     */
    private String player4;

    /**
     * The score of player 4.
     */
    private int score4 = 0;

    /**
     * The number of players that exist.
     */
    private int numberOfPlayers;

    /**
     * The current player.
     */
    private int currentPlayer = 1;

    /**
     * The scoring engine.
     */
    private final Scoring scoring;
        
    /**
     * Create new instance of MultiPlayer.
     *
     * @param tiles The language of the game.
     * @param players The names of the players. Must contain only 2, 3 or 4
     * Strings to represent the Scrabble players.
     */
    public MultiPlayer(Tiles tiles, String... players) {
        scoring = new Scoring(tiles);

        switch (players.length) {
            case 2:
                player1 = players[0];
                player2 = players[1];
                player3 = null;
                player4 = null;
                numberOfPlayers = 2;
                break;
            case 3:
                player1 = players[0];
                player2 = players[1];
                player3 = players[2];
                player4 = null;
                numberOfPlayers = 3;
                break;
            case 4:
                player1 = players[0];
                player2 = players[1];
                player3 = players[2];
                player4 = players[3];
                numberOfPlayers = 4;
                break;
        } //s
    }

    /**
     * Create new instance of MultiPlayer with 2 players.
     *
     * @param player1 Name of player 1.
     * @param player2 Name of player 2.
     * @param tiles The language of the game.
     * @return New instance of MultiPlayer.
     */
    public static MultiPlayer createTwoPlayer(String player1, String player2, Tiles tiles) {
        return new MultiPlayer(tiles, player1, player2);
    }

    /**
     * Create new instance of MultiPlayer with 3 players.
     *
     * @param player1 Name of player 1.
     * @param player2 Name of player 2.
     * @param player3 Name of player 3
     * @param tiles The language of the game.
     * @return New instance of MultiPlayer.
     */
    public static MultiPlayer createThreePlayer(String player1, String player2, String player3, Tiles tiles) {
        return new MultiPlayer(tiles, player1, player2, player3);
    }

    /**
     * Create new instance of MultiPlayer with 4 players.
     *
     * @param player1 Name of player 1.
     * @param player2 Name of player 2.
     * @param player3 Name of player 3
     * @param player4 Name of player 4.
     * @param tiles The language of the game.
     * @return New instance of MultiPlayer.
     */
    public static MultiPlayer createFourPlayer(String player1, String player2, String player3, String player4, Tiles tiles) {
        return new MultiPlayer(tiles, player1, player2, player3, player4);
    }

    /**
     * Set the score.
     *
     * @param scoreData The score data.
     * @throws ScrabbleException An error occurred.
     */
    public void setScore(ScoreData scoreData) throws ScrabbleException {
        //Add score to current player's score.
        int score;
        if(scoreData.isSkip()) {
            score = 0;
        } else{
            score = scoring.getMultipleScores(scoreData);
        } //ie
        
        switch (currentPlayer) {
            case 1:
                score1 += score;
                break;
            case 2:
                score2 += score;
                break;
            case 3:
                score3 += score;
                break;
            case 4:
                score4 += score;
                break;
        } //s
    }

    /**
     * Move to the next turn.
     */
    public void nextTurn() {
        //Move to next player's score.   
        switch (numberOfPlayers) {
            case 2:
                nextTwoPlayer();
                break;
            case 3:
                nextThreePlayer();
                break;
            case 4:
                nextFourPlayer();
                break;
        } //s
    }

    /**
     * Move to the next player if there are two players.
     */
    private void nextTwoPlayer() {
        if (currentPlayer == 1) {
            //Current player = 1.
            currentPlayer = 2;
        } else {
            //Current player = 2.
            this.currentPlayer = 1;
        } //ie
    }

    /**
     * Move to the next player if there are three players.
     */
    private void nextThreePlayer() {
        switch (currentPlayer) {
            case 1:
                currentPlayer = 2;
                break;
            case 2:
                currentPlayer = 3;
                break;
            default:
                currentPlayer = 1;
                break;
        } //ie
    }

    /**
     * Move to the next player if there are four players.
     */
    private void nextFourPlayer() {
        switch (currentPlayer) {
            case 1:
                currentPlayer = 2;
                break;
            case 2:
                currentPlayer = 3;
                break;
            case 3:
                currentPlayer = 4;
                break;
            default:
                currentPlayer = 1;
                break;
        } //ie
    }

    /**
     * Get the number of the current player.
     *
     * @return The number of the current player.
     */
    public int getCurrentPlayerNumber() {
        return currentPlayer;
    }

    /**
     * Get the name of the current player.
     *
     * @return The name of the current player.
     */
    public String getCurrentPlayerName() {
        switch (currentPlayer) {
            case 1:
                return player1;
            case 2:
                return player2;
            case 3:
                return player3;
            default:
                return player4;
        } //s
    }

    /**
     * Get the player's scores.
     *
     * @param number The number of the player.
     * @return The score of the player.
     */
    public int getPlayerScore(int number) {
        switch (number) {
            case 1:
                return score1;
            case 2:
                return score2;
            case 3:
                return score3;
            default:
                return score4;
        } //s
    }
}
