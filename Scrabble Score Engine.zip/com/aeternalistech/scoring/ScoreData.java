package com.aeternalistech.scoring;

import com.aeternalistech.enums.WordDirection;
import com.aeternalistech.coordinate.Coordinate;
import com.aeternalistech.enums.Compass;
import com.aeternalistech.misc.ScrabbleException;
import com.aeternalistech.misc.ScrabbleUtils;
import com.aeternalistech.tokenizer.GeneralTokenizer;
import com.aeternalistech.tokenizer.Tokenizer;
import com.aeternalistech.tokenizer.TokenizerException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Data representing a single user's score.
 *
 * @author George Miller
 * @version 1.1
 * @since 1.1
 */
public class ScoreData {

    /**
     * Set as true if the score is to be skipped (if no words can be placed of
     * if the player wants to switch tiles.)
     */
    private final boolean isSkip;

    /**
     * The word the user has placed.
     */
    private final String word;

    /**
     * The coordinate of the first tile of the word.
     */
    private final Coordinate coordinate;

    /**
     * The direction the word the word is pointing.
     */
    private final WordDirection direction;

    /**
     * Tiles that where added when this word was added to board.
     */
    private List<Coordinate> tilesAdded = new ArrayList<>();

    /**
     * The position of the tiles in the word. Some of these may be letters from
     * the board.
     */
    private List<Coordinate> tilesPositions = new ArrayList<>();

    /**
     * Create new instance of WordData.
     *
     * @param word The word. If you're skipping the turn set the word as "-".
     * @param coordinate The coordinate.
     * @param direction The direction of the word in the form h or horizontal
     * for a horizontal facing word or v or vertical for a vertical facing word.
     * @throws ScrabbleException There was an error when parsing the data
     * string.
     */
    public ScoreData(String word, String coordinate, String direction) throws ScrabbleException {
        word = word.toUpperCase();
        coordinate = coordinate.toUpperCase();
        direction = direction.toUpperCase();

        this.isSkip = "-".equals(word);

        if (this.isSkip) {
            this.word = null;
            this.coordinate = null;
            this.direction = null;
        } else {
            this.word = word;
            this.coordinate = new Coordinate(coordinate);

            //Get the direction.
            switch (direction) {
                case "H":
                case "HORIZONTAL":
                    this.direction = WordDirection.HORIZONTAL;
                    break;
                case "V":
                case "VERTICAL":
                    this.direction = WordDirection.VERTICAL;
                    break;
                default:
                    throw new ScrabbleException("Unrecognized direction!");
            } //s
        } //ie
    }

    /**
     * Create a new instance of ScoreData with the score data in a single
     * string. The score data parameters can be in any order and separated by
     * spaces or spaces and commas. For example "WORD, A1, H" "WORD V O7" are
     * both valid.
     *
     * @param dataString The data of the score data.
     * @return New instance of ScoreData.
     */
    public static ScoreData fromSingleString(String dataString) {
        Tokenizer tokenizer = new GeneralTokenizer(dataString, ',');

        //Extract tokens.
        String a, b, c;
        try {
            a = tokenizer.getNextToken();
            b = tokenizer.getNextToken();
            c = tokenizer.getNextToken();
        } catch (TokenizerException ex) {
            throw new IllegalArgumentException("Doesn't contain enough tokens!");
        } //tc

        //Test the orders.
        ScoreData data = null;
        boolean correct;

        //abc
        correct = true;
        try {
            data = new ScoreData(a, b, c);
        } catch (ScrabbleException ex) {
            correct = false;
        } //tc
        if (correct) {
            return data;
        } //i

        //acb
        correct = true;
        try {
            data = new ScoreData(a, c, b);
        } catch (ScrabbleException ex) {
            correct = false;
        } //tc
        if (correct) {
            return data;
        } //i

        //bac
        correct = true;
        try {
            data = new ScoreData(b, a, c);
        } catch (ScrabbleException ex) {
            correct = false;
        } //tc
        if (correct) {
            return data;
        } //i

        //bca
        correct = true;
        try {
            data = new ScoreData(b, c, a);
        } catch (ScrabbleException ex) {
            correct = false;
        } //tc
        if (correct) {
            return data;
        } //i

        //cab
        correct = true;
        try {
            data = new ScoreData(c, a, b);
        } catch (ScrabbleException ex) {
            correct = false;
        } //tc
        if (correct) {
            return data;
        } //i

        //cba
        correct = true;
        try {
            data = new ScoreData(c, b, a);
        } catch (ScrabbleException ex) {
            correct = false;
        } //tc
        if (correct) {
            return data;
        } //i

        throw new IllegalArgumentException("Tokens don't create legal ScoreData object!");
    }

    /**
     * Get if this is a skipped turn or not.
     *
     * @return True if this is a skipped turn, false if not.
     */
    public boolean isSkip() {
        return isSkip;
    }

    /**
     * Get the player's word.
     *
     * @return The player's word.
     */
    public String getWord() {
        return word;
    }

    /**
     * Get the coordinate of the first tile of the word.
     *
     * @return The coordinate of the first tile of the word.
     */
    public Coordinate getCoordinate() {
        return coordinate;
    }

    /**
     * Get the direction the word is pointing.
     *
     * @return The direction the word is pointing.
     */
    public WordDirection getDirection() {
        return direction;
    }

    /**
     * Set the coordinates of the squares of the tiles that are added during
     * this move.
     *
     * @param added the coordinates of the squares of the tiles that are added
     * during this move.
     */
    public void setAdded(List<Coordinate> added) {
        //If this method has already been called, return.
        if (!this.tilesAdded.isEmpty()) {
            return;
        } //i

        added.stream().forEach((square) -> {
            this.tilesAdded.add(square);
        });
    }

    /**
     * Get the coordinates of the squares of the tiles that where added. This
     * remains blank until this word is added to the board.
     *
     * @return The coordinates of the squares of the tiles that where added.
     */
    public List<Coordinate> getAdded() {
        List<Coordinate> copyAdded = new ArrayList<>();

        for (int i = 0; i < tilesAdded.size(); i++) {
            copyAdded.add(tilesAdded.get(i));
        } //f

        return copyAdded;
    }

    /**
     * Get the position of the tiles on the board. If this word contains tiles
     * that are already on the board these coordinates are added too. If you
     * don't want these coordinates that call the getAdded method.
     *
     * @return The coordinates of the squares of the tiles on the board.
     */
    public List<Coordinate> getPosition() {
        //If the tilesPositions List is full, use it.
        if (!tilesPositions.isEmpty()) {
            List<Coordinate> copy = new ArrayList<>();

            tilesPositions.stream().forEach((square) -> {
                copy.add(square.copy());
            });

            return copy;
        } //i

        //Fill the tilesPositions List.
        if (direction == WordDirection.HORIZONTAL) {
            //Horizontal word - move east.
            Coordinate move = coordinate.copy();
            for (int i = 0; i < word.length(); i++) {
                tilesPositions.add(move);

                try {
                    move = ScrabbleUtils.move(move, Compass.EAST);
                } catch (ScrabbleException ex) {
                } //tc
            } //fe
        } else {
            //Vertical word - move south.
            Coordinate move = coordinate.copy();
            for (int i = 0; i < word.length(); i++) {
                tilesPositions.add(move);

                try {
                    move = ScrabbleUtils.move(move, Compass.SOUTH);
                } catch (ScrabbleException ex) {
                } //tc
            } //fe
        } //ie

        return getPosition();
    }

    @Override
    public String toString() {
        StringBuilder build = new StringBuilder();

        build.append(word);
        build.append(", ");

        build.append(coordinate.getX());
        build.append(coordinate.getY());
        build.append(", ");

        if (direction == WordDirection.HORIZONTAL) {
            build.append("H");
        } else {
            build.append("V");
        } //ie

        return build.toString();
    }
}
