package com.aeternalistech.scoring;

import com.aeternalistech.board.ScrabbleBoard;
import com.aeternalistech.board.TilesLeft;
import com.aeternalistech.misc.ScrabbleException;
import com.aeternalistech.tiles.Tiles;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Convenient two player scoring engine.
 *
 * @author George Miller
 * @version 1.1
 * @since 1.1
 */
public class TwoPlayerScoringEngine {

    /**
     * The language of the game.
     */
    private final Tiles tiles;

    /**
     * Multiplayer scoring engine.
     */
    private final MultiPlayer mp;

    /**
     * Single player scoring (test).
     */
    private final Scoring scoring;

    /**
     * The scrabble board.
     */
    private final ScrabbleBoard board = ScrabbleBoard.getInstance();

    /**
     * The tiles left.
     */
    private final TilesLeft tilesLeft = TilesLeft.getInstance();

    /**
     * Stores the scores.
     */
    private final TwoPlayerStorage storage;

    /**
     * Create new instance of Game.
     *
     * @param tiles The language of the game.
     * @param player1 The name of player 1.
     * @param player2 The name of player 2.
     * 
     */
    public TwoPlayerScoringEngine(Tiles tiles, String player1, String player2) {
        this.tiles = tiles;
        this.mp = new MultiPlayer(tiles, player1, player2);

        storage = new TwoPlayerStorage(mp);
        tilesLeft.reset(tiles);
        scoring = new Scoring(tiles);
    }

    /**
     * Get the score of the word and all connected words.
     *
     * @param scoreData Score data.
     * @return The score of the word and all connected words.
     * @throws ScrabbleException Error in scoring engine.
     */
    public int getScore(ScoreData scoreData) throws ScrabbleException {
        int score = scoring.getMultipleScores(scoreData);
        return score;
    }

    /**
     * See the score data for the word and all connected words.
     *
     * @param scoreData Score data.
     * @return The score data for the word and all connected words.
     * @throws ScrabbleException Error in scoring engine.
     */
    public String getScoreData(ScoreData scoreData) throws ScrabbleException {
        String data = scoring.getScoreData(scoreData);
        return data;
    }

    /**
     * Add player word to scoring engine.
     *
     * @param scoreData Score data.
     * @throws ScrabbleException Error in scoring engine.
     */
    public void addWord(ScoreData scoreData) throws ScrabbleException {
        mp.setScore(scoreData);
        storage.addScore(scoreData);

        if (!scoreData.isSkip()) {
            board.addWord(scoreData);
            tilesLeft.removeWord(scoreData);
        } //i

        mp.nextTurn();
    }

    /**
     * Get the tiles left.
     *
     * @return The tiles left.
     */
    public String getTilesLeft() {
        return tilesLeft.getTilesLeft();
    }
    
    /**
     * Calculate the score of the end tiles.
     */
    public void calculateEndScore() {
        //Determine the value of the end tiles.
        String endTiles = tilesLeft.getTilesLeft();
        char[] endChars = endTiles.toCharArray();
        int endScore = 0;
        
        for(char character : endChars) {
            try {
                endScore += tiles.getScore(character);
            } catch (ScrabbleException ex) {
            } //tc
        } //f
        
        //Determine which player gets minus and which gets plus.
        int currentPlayer = mp.getCurrentPlayerNumber();
        if(currentPlayer == 1) {
            //The last player was 2, player 2 gets the score.
            String player2 = "+" + endTiles + " " + (mp.getPlayerScore(2) + endScore);
            String player1 = "-" + endTiles + " " + (mp.getPlayerScore(1) - endScore);
            
            storage.addPlayer1(player1);
            storage.addPlayer2(player2);
        } else {
            //The last player was 1, player 1 gets the score.
            String player1 = "+" + endTiles + " " + (mp.getPlayerScore(1) + endScore);
            String player2 = "-" + endTiles + " " + (mp.getPlayerScore(2) - endScore);
            
            storage.addPlayer1(player1);
            storage.addPlayer2(player2);
        } //ie
    }

    /**
     * Get the score.
     *
     * @return The score.
     */
    public String getScore() {
        return storage.toString();
    }
}
