package com.aeternalistech.scoring;

import com.aeternalistech.misc.ScrabbleException;

/**
 * Stores the score for a two player game.
 *
 * @author George Miller
 * @version 1.1
 * @since 1.1
 */
public class TwoPlayerStorage {

    /**
     * The length of the String on the left hand side.
     */
    private static final int LENGTH = 35;

    /**
     * The builder.
     */
    private final StringBuilder build = new StringBuilder();

    /**
     * Multiplayer engine to get scores from.
     */
    private final MultiPlayer multiplayer;

    /**
     * Create new instance of ScoreStorage.
     *
     * @param multiPlayer Multiplayer engine to get scores from.
     */
    public TwoPlayerStorage(MultiPlayer multiPlayer) {
        this.multiplayer = multiPlayer;
    }

    /**
     * Add score to storage.
     *
     * @param scoreData ScoreData to add.
     * @throws ScrabbleException Player number isn't 1 or 2.
     */
    public void addScore(ScoreData scoreData) throws ScrabbleException {
        int player = multiplayer.getCurrentPlayerNumber();

        switch (player) {
            case 1:
                addPlayer1(scoreData);
                break;
            case 2:
                addPlayer2(scoreData);
                break;
            default:
                throw new ScrabbleException("Invalid player number!");
        } //s
    }

    /**
     * Add player 1 score.
     *
     * @param scoreData Data for player 1.
     */
    private void addPlayer1(ScoreData scoreData) {
        String str;
        //Check if there is a score or blank.
        if (scoreData.isSkip()) {
            //Skip.
            str = "--- (0)";
            build.append(str);
        } else {
            //Score.
            //Add string to builder. 
            str = scoreData + " (" + multiplayer.getPlayerScore(1) + ")";
            build.append(str);
        } //ie

        //Add blank spaces.
        int length = LENGTH - str.length();
        for (int i = 0; i < length; i++) {
            build.append(' ');
        } //f

        //Add |
        build.append("|   ");
    }

    /**
     * Add player 2 score.
     *
     * @param scoreData Data for player 2.
     */
    private void addPlayer2(ScoreData scoreData) {
        String str;
        //Check if there is a score or blank.
        if (scoreData.isSkip()) {
            //Skip.
            str = "--- (0)";
            build.append(str);
        } else {
            //Score.
            //Add string to builder. 
            str = scoreData + " (" + multiplayer.getPlayerScore(2) + ")";
            build.append(str);
        } //ie

        //Newline in text file.
        build.append((char) 13);
        build.append((char) 10);
    }
    
    /**
     * Add player 1 data.
     *
     * @param data Player 1 data.
     */
    public void addPlayer1(String data) {
        build.append(data);

        //Add blank spaces.
        int length = LENGTH - data.length();
        for (int i = 0; i < length; i++) {
            build.append(' ');
        } //f

        //Add |
        build.append("|   ");
    }

    /**
     * Add player 2 data.
     *
     * @param data Player 2 data.
     */
    public void addPlayer2(String data) {
        build.append(data);

        //Newline in text file.
        build.append((char) 13);
        build.append((char) 10);
    }
    
    @Override
    public String toString() {
        return build.toString();
    }
}
